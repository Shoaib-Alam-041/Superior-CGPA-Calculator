const gradeMapping = {
    "A": 4.0, "A-": 3.7, "B+": 3.3, "B": 3.0, "B-": 2.7,
    "C+": 2.3, "C": 2.0, "C-": 1.7, "D+": 1.3, "D": 1.0, "F": 0.0
};

function addRow() {
    const table = document.getElementById("gradeTable").getElementsByTagName("tbody")[0];
    const newRow = table.insertRow();

    newRow.innerHTML = `
        <td><input type="text" placeholder="Course Name"></td>
        <td>
            <select>
                <option value="A">A</option>
                <option value="A-">A-</option>
                <option value="B+">B+</option>
                <option value="B">B</option>
                <option value="B-">B-</option>
                <option value="C+">C+</option>
                <option value="C">C</option>
                <option value="C-">C-</option>
                <option value="D+">D+</option>
                <option value="D">D</option>
                <option value="F">F</option>
            </select>
        </td>
        <td><input type="number" min="1" value="3"></td>
        <td><button onclick="removeRow(this)">❌</button></td>
    `;
}

function removeRow(button) {
    const row = button.parentElement.parentElement;
    row.parentElement.removeChild(row);
}

function calculateCGPA() {
    let totalPoints = 0, totalCredits = 0;
    const rows = document.querySelectorAll("#gradeTable tbody tr");

    if (rows.length === 0) {
        document.getElementById("result").innerText = "Please add courses before calculating.";
        return;
    }

    rows.forEach(row => {
        const grade = row.cells[1].querySelector("select").value;
        const credits = parseFloat(row.cells[2].querySelector("input").value);

        if (!isNaN(credits) && credits > 0) {
            totalPoints += gradeMapping[grade] * credits;
            totalCredits += credits;
        }
    });

    if (totalCredits === 0) {
        document.getElementById("result").innerText = "Invalid input! Credit hours must be greater than 0.";
        return;
    }

    const cgpa = (totalPoints / totalCredits).toFixed(2);
    document.getElementById("result").innerText = `Your CGPA is: ${cgpa}`;
}
